<?php

$currentdir = '/var/www/ryanshotwell.com/college/comm2160/';

$allowedEXTs = array('gif', 'jpg', 'jpeg', 'png');
$allowedIMGtype = array('image/gif', 'image/jpg', 'image/jpeg', 'image/png');

?>